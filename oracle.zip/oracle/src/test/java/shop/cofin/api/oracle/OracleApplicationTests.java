package shop.cofin.api.oracle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OracleApplicationTests {

	@Test
	void contextLoads() {
	}

}
